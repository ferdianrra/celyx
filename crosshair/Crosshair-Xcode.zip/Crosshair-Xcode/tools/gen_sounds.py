"""Render the crosshair SFX to 48 kHz mono WAVs (same recipes as the web preview).
Usage: python3 gen_sounds.py <out_dir>   (needs numpy)"""
import sys, wave, math
import numpy as np
SR = 48000
rng = np.random.default_rng(7)

def env(n, t0, a, peak, dur):
    """Web Audio style: exp ramp 0.0001 -> peak over a, then exp ramp -> 0.0001 at dur."""
    t = np.arange(n) / SR - t0
    out = np.zeros(n)
    m1 = (t >= 0) & (t < a)
    out[m1] = 0.0001 * (peak / 0.0001) ** (t[m1] / a)
    m2 = (t >= a) & (t < dur)
    out[m2] = peak * (0.0001 / peak) ** ((t[m2] - a) / (dur - a))
    return out

def bandpass(x, f0, f1, q, t0, dur):
    y = np.zeros_like(x); x1 = x2 = y1 = y2 = 0.0
    for i in range(len(x)):
        tt = min(max(i / SR - t0, 0), dur)
        f = f0 * (f1 / f0) ** (tt / dur) if f1 else f0
        w0 = 2 * math.pi * f / SR; al = math.sin(w0) / (2 * q)
        b0, b2, a0, a1, a2 = al, -al, 1 + al, -2 * math.cos(w0), 1 - al
        yi = (b0 * x[i] + b2 * x2 - a1 * y1 - a2 * y2) / a0
        x2, x1 = x1, x[i]; y2, y1 = y1, yi; y[i] = yi
    return y

def click(buf, t0, f, g, d, q=4, f2=None, a=0.001):
    n = len(buf); s0 = int(t0 * SR); s1 = min(n, s0 + int((d + 0.03) * SR))
    seg = rng.uniform(-1, 1, s1 - s0)
    seg = bandpass(seg, f, f2, q, 0, d)
    buf[s0:s1] += seg * env(s1 - s0, 0, a, g, d)

def tone(buf, t0, f, g, d, f2=None, glide=None, typ="sine", a=0.004):
    n = len(buf); s0 = int(t0 * SR); s1 = min(n, s0 + int((d + 0.03) * SR))
    t = np.arange(s1 - s0) / SR
    if f2:
        gl = glide or d
        fr = np.where(t < gl, f * (f2 / f) ** (np.minimum(t, gl) / gl), f2)
    else:
        fr = np.full_like(t, f)
    ph = 2 * math.pi * np.cumsum(fr) / SR
    w = np.sin(ph) if typ == "sine" else (2 / math.pi) * np.arcsin(np.sin(ph))
    buf[s0:s1] += w * env(s1 - s0, 0, a, g, d)

# Target peak per sound (mix balance between events).
PEAK = {"lock": .9, "acquire": .55, "validate": .5, "back": .38, "release": .32, "ready": .16, "kick": .24}

def render(name, length, fn, out):
    b = np.zeros(int(length * SR)); fn(b)
    b /= (np.max(np.abs(b)) or 1)
    b = np.tanh(b * 1.3) / np.tanh(1.3)   # gentle soft-clip
    b *= PEAK["kick" if name.startswith("kick") else name]
    fade = int(.004 * SR); b[-fade:] *= np.linspace(1, 0, fade)
    d = (b * 32767).astype(np.int16)
    with wave.open(f"{out}/crosshair_{name}.wav", "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes(d.tobytes())

T = 0.005
def acquire(b): click(b, T, 3400, .28, .025, q=5); tone(b, T, 1480, .07, .09, f2=1980, glide=.05)
def lock(b):
    click(b, T, 2200, .55, .04, q=2.5); click(b, T + .045, 3600, .22, .02, q=4)
    tone(b, T, 150, .5, .13, f2=52, glide=.09)
    tone(b, T + .03, 1318.5, .09, .5); tone(b, T + .03, 1322, .04, .5)
    tone(b, T + .095, 1975.5, .075, .7); tone(b, T + .095, 2637, .025, .45)
def validate(b): click(b, T, 700, .12, .3, q=1.4, f2=3400, a=.06); tone(b, T, 880, .05, .22, f2=1318, glide=.18, typ="tri")
def back(b): click(b, T, 1500, .14, .02, q=4); tone(b, T, 990, .05, .16, f2=560, typ="tri")
def release(b): tone(b, T, 1318, .04, .2, f2=880, typ="tri")
def ready(b): click(b, T, 6000, .035, .012, q=10)
def kick(i): return lambda b: click(b, T, 5200 - i * 350, .07, .014, q=9)

if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else "."
    for name, length, fn in [("acquire", .15, acquire), ("lock", .85, lock), ("validate", .35, validate), ("back", .2, back),
                             ("release", .25, release), ("ready", .05, ready)] + [(f"kick{i}", .05, kick(i)) for i in range(4)]:
        render(name, length, fn, out); print("wrote", name)
